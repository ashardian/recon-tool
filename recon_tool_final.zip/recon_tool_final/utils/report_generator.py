import json
import datetime

def generate_report(data, filename="report.html"):
    time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    html = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Recon Report</title>
        <style>
            body {{
                font-family: 'Segoe UI', Arial, sans-serif;
                background: #f4f4f9;
                color: #222;
                margin: 0;
                padding: 0;
            }}
            .container {{
                max-width: 900px;
                margin: 40px auto;
                background: #fff;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.08);
                padding: 32px 40px 24px 40px;
            }}
            h1 {{
                color: #2c3e50;
                border-bottom: 2px solid #e67e22;
                padding-bottom: 8px;
            }}
            h2 {{
                color: #e67e22;
                margin-top: 32px;
                border-bottom: 1px solid #eee;
                padding-bottom: 4px;
            }}
            pre {{
                background: #f8f8f8;
                border: 1px solid #e1e1e8;
                border-radius: 4px;
                padding: 12px;
                overflow-x: auto;
                font-size: 15px;
                line-height: 1.5;
            }}
            .footer {{
                margin-top: 40px;
                text-align: center;
                color: #888;
                font-size: 14px;
            }}
            .meta {{
                color: #555;
                font-size: 16px;
                margin-bottom: 24px;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Reconnaissance Report</h1>
            <div class="meta">
                <strong>Generated:</strong> {time}
            </div>
            <h2>WHOIS Information</h2>
            <pre>{data.get('whois', 'No WHOIS data available.')}</pre>
            <h2>DNS Records</h2>
            <pre>{json.dumps(data.get('dns', {}), indent=2)}</pre>
            <h2>Subdomains</h2>
            <pre>{json.dumps(data.get('subdomains', []), indent=2)}</pre>
            <h2>Open Ports</h2>
            <pre>{json.dumps(data.get('ports', []), indent=2)}</pre>
            <h2>Banners</h2>
            <pre>{json.dumps(data.get('banners', {}), indent=2)}</pre>
            <h2>Technology Detection</h2>
            <pre>{data.get('tech', 'No technology data available.')}</pre>
            <div class="footer">
                &copy; {datetime.datetime.now().year} Recon Tool &mdash; Copyright Ashar Dian
            </div>
        </div>
    </body>
    </html>
    """
    with open(filename, "w", encoding="utf-8") as f:
        f.write(html)
