import requests

def enumerate(domain):
    url = f"https://crt.sh/?q=%25.{domain}&output=json"
    try:
        response = requests.get(url, timeout=10)
        data = response.json()
        return sorted(set(entry['name_value'] for entry in data))
    except Exception as e:
        return f"Error: {e}"
